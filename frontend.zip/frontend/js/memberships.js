document.addEventListener("DOMContentLoaded", loadMemberships);

async function loadMemberships() {
  showLoading("memberships-table-container");
  try {
    const memberships = await getData("/memberships/");
    renderMembershipsTable(memberships);
  } catch (error) {
    console.error("Error loading memberships:", error);
    showError("memberships-table-container", "Could not load memberships.");
  }
}

function renderMembershipsTable(memberships) {
  const container = document.getElementById("memberships-table-container");

  if (!memberships || memberships.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h5>No memberships found</h5>
        <p>Create the first membership to link a member with a plan.</p>
      </div>`;
    return;
  }

  container.innerHTML = `
    <div class="table-responsive">
      <table class="table align-middle">
        <thead>
          <tr>
            <th>ID</th><th>Member ID</th><th>Plan ID</th>
            <th>Start Date</th><th>End Date</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${memberships.map(m => `
            <tr>
              <td>${m.id}</td>
              <td>${m.member_id}</td>
              <td>${m.plan_id}</td>
              <td>${formatDate(m.start_date)}</td>
              <td>${formatDate(m.end_date)}</td>
              <td>${renderMembershipBadge(m.status)}</td>
              <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditModal(${m.id}, '${m.status}')">
                  <i class="bi bi-pencil"></i> Edit
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete(${m.id})">
                  <i class="bi bi-trash"></i> Cancel
                </button>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;
}

function renderMembershipBadge(status) {
  if (status === "active")    return `<span class="badge badge-soft-success">Active</span>`;
  if (status === "pending")   return `<span class="badge badge-soft-warning">Pending</span>`;
  if (status === "expired")   return `<span class="badge badge-soft-danger">Expired</span>`;
  if (status === "cancelled") return `<span class="badge badge-soft-danger">Cancelled</span>`;
  return `<span class="badge badge-soft-warning">${status}</span>`;
}

// ── ADD ───────────────────────────────────────────────────────────────────
async function openAddModal() {
  const today = new Date().toISOString().split("T")[0];
  document.getElementById("membershipStartDate").value = today;
  document.getElementById("add-form-error").classList.add("d-none");
  document.getElementById("planInfoPrice").value    = "";
  document.getElementById("planInfoDuration").value = "";

  const memberSelect = document.getElementById("membershipMemberId");
  const planSelect   = document.getElementById("membershipPlanId");
  memberSelect.innerHTML = `<option value="">Loading members...</option>`;
  planSelect.innerHTML   = `<option value="">Loading plans...</option>`;

  const [membersResult, plansResult] = await Promise.allSettled([
    getData("/members/"),
    getData("/plans/")
  ]);

  // Populate members
  memberSelect.innerHTML = membersResult.status === "fulfilled" && membersResult.value?.length
    ? `<option value="">Select a member...</option>` +
      membersResult.value.map(m =>
        `<option value="${m.id}">${m.id} — ${m.first_name} ${m.last_name}</option>`
      ).join("")
    : `<option value="">Could not load members</option>`;

  // Populate plans — options en una sola línea para evitar problemas de parsing
  const plans = plansResult.status === "fulfilled" ? plansResult.value : [];
  if (plans.length) {
    const options = plans.map(p => {
      const opt = document.createElement("option");
      opt.value = p.id;
      opt.textContent = `${p.id} — ${p.name}`;
      opt.setAttribute("data-price", p.price);
      opt.setAttribute("data-duration", p.duration_days);
      return opt;
    });
    planSelect.innerHTML = "";
    const defaultOpt = document.createElement("option");
    defaultOpt.value = "";
    defaultOpt.textContent = "Select a plan...";
    planSelect.appendChild(defaultOpt);
    options.forEach(opt => planSelect.appendChild(opt));
  } else {
    planSelect.innerHTML = `<option value="">Could not load plans</option>`;
  }

  new bootstrap.Modal(document.getElementById("addMembershipModal")).show();
}

function onPlanSelected() {
  const planSelect     = document.getElementById("membershipPlanId");
  const selectedOption = planSelect.options[planSelect.selectedIndex];

  const price    = selectedOption ? selectedOption.getAttribute("data-price")    : null;
  const duration = selectedOption ? selectedOption.getAttribute("data-duration") : null;

  if (price && duration && planSelect.value !== "") {
    document.getElementById("planInfoPrice").value    = `€ ${parseFloat(price).toFixed(2)}`;
    document.getElementById("planInfoDuration").value = `${duration} days`;
  } else {
    document.getElementById("planInfoPrice").value    = "";
    document.getElementById("planInfoDuration").value = "";
  }
}

async function submitAddMembership() {
  const memberId  = document.getElementById("membershipMemberId").value;
  const planId    = document.getElementById("membershipPlanId").value;
  const startDate = document.getElementById("membershipStartDate").value;
  const status    = document.getElementById("membershipStatus").value;
  const errorDiv  = document.getElementById("add-form-error");

  if (!memberId) { errorDiv.textContent = "Please select a member."; errorDiv.classList.remove("d-none"); return; }
  if (!planId)   { errorDiv.textContent = "Please select a plan.";   errorDiv.classList.remove("d-none"); return; }
  if (!startDate){ errorDiv.textContent = "Start date is required."; errorDiv.classList.remove("d-none"); return; }

  errorDiv.classList.add("d-none");

  try {
    await postData("/memberships/", {
      member_id: parseInt(memberId), plan_id: parseInt(planId),
      start_date: startDate, status
    });
    bootstrap.Modal.getInstance(document.getElementById("addMembershipModal")).hide();
    showSuccess("Membership created successfully!");
    loadMemberships();
  } catch (error) {
    errorDiv.textContent = "Could not save membership. Try again.";
    errorDiv.classList.remove("d-none");
  }
}

// ── EDIT ──────────────────────────────────────────────────────────────────
function openEditModal(id, currentStatus) {
  document.getElementById("editMembershipId").value     = id;
  document.getElementById("editMembershipStatus").value = currentStatus;
  document.getElementById("edit-form-error").classList.add("d-none");
  new bootstrap.Modal(document.getElementById("editMembershipModal")).show();
}

async function submitEditMembership() {
  const id       = document.getElementById("editMembershipId").value;
  const status   = document.getElementById("editMembershipStatus").value;
  const errorDiv = document.getElementById("edit-form-error");
  errorDiv.classList.add("d-none");
  try {
    await patchData(`/memberships/${id}`, { status });
    bootstrap.Modal.getInstance(document.getElementById("editMembershipModal")).hide();
    showSuccess("Membership updated successfully!");
    loadMemberships();
  } catch (error) {
    errorDiv.textContent = "Could not update membership. Try again.";
    errorDiv.classList.remove("d-none");
  }
}

// ── CANCEL ────────────────────────────────────────────────────────────────
function confirmDelete(id) {
  document.getElementById("cancelMembershipId").value = id;
  new bootstrap.Modal(document.getElementById("cancelMembershipModal")).show();
}

async function submitCancelMembership() {
  const id = document.getElementById("cancelMembershipId").value;
  try {
    await patchData(`/memberships/${id}`, { status: "cancelled" });
    bootstrap.Modal.getInstance(document.getElementById("cancelMembershipModal")).hide();
    showSuccess("Membership cancelled successfully.");
    loadMemberships();
  } catch (error) {
    console.error("Error cancelling membership:", error);
  }
}